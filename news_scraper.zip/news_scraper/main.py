import base64

from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from news_scraper.spiders.infoworld import InfoworldSpider
from news_scraper.spiders.devmozilla import MozillaDev



def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    process = CrawlerProcess(get_project_settings())
    process.crawl(InfoworldSpider)
    process.crawl(MozillaDev)
    process.start()
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    print(pubsub_message)
